# Elicit 2 Sci-Hub

Click on the DOI icon next to a paper and open it straight in Sci-Hub.

Installation:

1. Download Zip and put unpacked folder in a location you can keep it permanently
2. Go to chrome://Extensions
3. Click on "Load Extension"
4. Select the unpacked folder
5. Done!
